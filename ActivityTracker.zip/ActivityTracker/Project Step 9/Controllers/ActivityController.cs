﻿using Microsoft.AspNetCore.Mvc;
using Project_Step_9.Models;
using System.Linq;

namespace Project_Step_9.Controllers
{
    public class ActivityController : Controller
    {


        //Field 

        private IActivityRepository _repository;

        // Constructors 

        public ActivityController(IActivityRepository repository)
        {
            _repository = repository;
        }


        // Methods


        // Create

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(Activity a)
        {
            if (ModelState.IsValid)
            {
                _repository.Create(a);
                return RedirectToAction("Details", new { id = a.Id });  //This adds activityrecord a to db
            }
            return View(a);
        }

        // Read

        public IActionResult Index()
        {
            IQueryable<Activity> activity = _repository.GetAllActivities();
            return View(activity);
        }


        //Read an activity out of a db and display it on web page
        public IActionResult Details(int id)
        {
            Activity a = _repository.GetActivityById(id);
            return View(a);
        }


        // Update

        [HttpGet]
        public IActionResult Edit(int id)
        {
            //1. Read an activity out of a db 

            Activity a = _repository.GetActivityById(id);

            // ActivityRecord a = new ActivityRecord();
            // a.RecordID = 1;
            // a.ActivityId = 2;
            // a.Date = "2 May 2020";
            // a.Distance = 20;
            // a.Location = "Colorado Springs";
            // a.TimeRecord = "2 hrs";

            //2. display it so user can change some fields 

            return View(a);
        }

        [HttpPost]
        public IActionResult Edit(Activity a)
        {
            if (ModelState.IsValid)
            {
                // Update the activity record (a) in the DB
                _repository.Update(a);
                return RedirectToAction("Details", new { id = a.Id });
            }
            return View(a);
        }




        //Delete

        [HttpGet]
        public IActionResult Delete(int id)
        {
            Activity a = _repository.GetActivityById(id);
            return View(a);
        }

        [HttpPost]
        public IActionResult Delete(Activity a)
        {
            _repository.Delete(a.Id);
            return RedirectToAction("Index");
        }



    } //END OF CLASS
}
