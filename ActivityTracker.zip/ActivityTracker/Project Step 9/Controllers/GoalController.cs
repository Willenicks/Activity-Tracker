﻿using Microsoft.AspNetCore.Mvc;
using Project_Step_9.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project_Step_9.Controllers
{
    public class GoalController : Controller
    {

        // Fields and Properties

        private IGoalRepository _repository;

        // Constructors

        public GoalController(IGoalRepository repository)
        {
            _repository = repository;
        }

        // Methods

        // Create

        [HttpGet]
        public IActionResult Create(int goalId)
        {
            Goal g = new Goal { Id = goalId };
            return View(g);
        }

        [HttpPost]
        public IActionResult Create(Goal g)
        {
            if (ModelState.IsValid)
            {
                _repository.Create(g);
                return RedirectToAction("Details", new { id = g.Id });
            }
            return View(g);
        }


        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Details(int id)
        {
            Goal g = _repository.GetGoalById(id);
            if (g ==null)
            {
                return RedirectToAction("Index", "ActivityType");
            }
            return View(g);
        }


        //Update

        [HttpGet]
        public IActionResult Edit(int id)
        {
            Goal g = _repository.GetGoalById(id);
            return View(g);
        }

        [HttpPost]
        public IActionResult Edit(Goal g)
        {
            if (ModelState.IsValid)
            {
                _repository.Update(g);
                return RedirectToAction("Details", new { id = g.Id });
            }
            return View(g);
        }

        //Delete

        [HttpGet]
        public IActionResult Delete(int id)
        {
            Goal g = _repository.GetGoalById(id);
            if (g == null)
            {
                return RedirectToAction("Index", "ActivityType");
            }
            return View(g);
        }

        [HttpPost]

        public IActionResult Delete(Goal g)
        {            
            _repository.Delete(g);
            return RedirectToAction("Index", "Goal");
        }
    } // End of Class
}
