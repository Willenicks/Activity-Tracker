﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project_Step_9.Models
{
    public class EfGoalRepository : IGoalRepository
    {
        // Fields and Properties

        private AppDbContext _context;


        //Constructors


        public EfGoalRepository(AppDbContext context)
        {
            _context = context;
        }

        // Methods

        //Create

        public Goal Create(Goal g)
        {
            _context.Goals.Add(g);
            _context.SaveChanges();
            return g;
        }



        //Read

        public IQueryable<Goal> GetAllGoals()
        {
            return _context.Goals;
        }

        public IQueryable<Goal> GetAllGoals(int activityTypeId)
        {
            return _context.Goals.Where(g => g.ActivityTypeId == activityTypeId);
        }

        public Goal GetGoalById(int goalId)
        {
            return _context.Goals.Include(g => g.ActivityType).FirstOrDefault(g => g.Id == goalId);
        }


        // Update


        public Goal Update(Goal g)
        {
            Goal GoalToupdate = GetGoalById(g.Id);
            if (GoalToupdate != null)
            {
                GoalToupdate.Time = g.Time;
                GoalToupdate.Location = g.Location;
                GoalToupdate.Distance = g.Distance;
                _context.SaveChanges();
            }
            return GoalToupdate;
        }


        //delete


        public bool Delete(Goal g)
        {
            Goal GoalToDelete = GetGoalById(g.Id);
            if(GoalToDelete == null)
            {
                return false;
            }
            _context.Goals.Remove(GoalToDelete);
            _context.SaveChanges();
            return true;
        }
    }
}
