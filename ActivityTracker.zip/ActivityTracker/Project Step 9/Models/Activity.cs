﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Project_Step_9.Models
{
    public class Activity     //POCO
    {
        // Fields and Properties

       [Key]
        public int       Id     { get; set; }
        
        [Required]

        public int       ActivityTypeId   { get; set; }

        public ActivityType ActivityType { get; set; }

        [Required]

        public string    Date         { get; set; }

        public string    Location     { get; set; }

        public int       Distance     { get; set; }

        public string    Time   { get; set; }



        // Constructors



        // Methods

    }
}
