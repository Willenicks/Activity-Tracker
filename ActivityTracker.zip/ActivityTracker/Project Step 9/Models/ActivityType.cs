﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Project_Step_9.Models
{
   public class ActivityType
   {
       // Fields
   
       [Key]
       public int Id { get; set; }
   
       [Required]
   
      // public int userId { get; set; }
   
       public string Name { get; set; }
   
       public IEnumerable<Goal> Goals { get; set; }

       public IEnumerable<Activity> Activities { get; set; }
   
   
       // Constructors 
   
   
       // Methods
   
   }
}
