﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace Project_Step_9.Models
{
    public class AppDbContext : DbContext

    {
        // F I E L D S AND P R O P E R T I E S 

        public DbSet<Goal> Goals { get; set; }

        public DbSet<Activity> Activities { get; set; }
        public IEnumerable<ActivityType> ActivityTypes { get; set; }


        // C O N S T R U C T O R S 

        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {

        }


        // M E T H O D S

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<ActivityType>().HasData(new ActivityType
            {
                Id = 1,
                Name = "Running"

            });

            modelBuilder.Entity<ActivityType>().HasData(new ActivityType
            {
                Id = 2,
                Name = "Swimming"

            });

            modelBuilder.Entity<ActivityType>().HasData(new ActivityType
            {
                Id = 3,
                Name = "Biking"

            });


            //Records
            modelBuilder.Entity<Activity>().HasData(new Activity
            {
                   Id = 1,
                   ActivityTypeId = 1,
                   Date = "2 May 2020",
                   Location = "Denver",
                   Distance = 20,
                   Time = "3 hours"
               });

            modelBuilder.Entity<Activity>().HasData(new Activity
            {
                Id = 2,
                ActivityTypeId = 1,
                Date = "4 April 2020",
                Location = "Colorado Springs",
                Distance = 10,
                Time = "1 hour"
            });

            // G o a l s
            modelBuilder.Entity<Goal>().HasData(new Goal
            {
                Id = 1,                
                Location = "Colorado Springs",
                Distance = 13,
                Time = "1.5 hours",
                ActivityTypeId = 1
            });

            modelBuilder.Entity<Goal>().HasData(new Goal
            {
                Id = 2,
                Location = "Steamboat Springs",
                Distance = 26,
                Time = "4 hours",
                ActivityTypeId = 1
            });
        }
    } // end of class
}
