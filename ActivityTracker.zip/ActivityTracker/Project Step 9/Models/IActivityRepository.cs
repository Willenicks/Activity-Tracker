﻿using System.Linq;

namespace Project_Step_9.Models
{
    public interface IActivityRepository
    {
        // C R E A T E

        public Activity Create(Activity a);


        // R E A D 

        public IQueryable<Activity> GetAllActivities();

        public Activity GetActivityById(int id);

        // U P D A T E 

        public Activity Update(Activity a);


        // D E L E T E


        public bool Delete(int id);
    }
}
