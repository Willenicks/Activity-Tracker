﻿using System;
using System.Collections.Generic;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Project_Step_9.Models
{
    [Table("Goal")]
    public class Goal
    {
        [Key]
        public int Id { get; set; }

        public string Time { get; set; }


       // [Column(TypeName = "decimal(3 , 2)")]
        public float Distance { get; set; }

        public string Location { get; set; }

        public int ActivityTypeId { get; set; }

        [Required]
        public ActivityType ActivityType { get; set; }

    }
}
