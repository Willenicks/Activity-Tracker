﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project_Step_9.Models
{
   public interface IGoalRepository
    {
        //Create

        public Goal Create(Goal g);



        //Read

        public IQueryable<Goal> GetAllGoals();
        public IQueryable<Goal> GetAllGoals(int activityTypeId);


        public Goal GetGoalById(int goalId);


        // Update


        public Goal Update(Goal g);


        //delete


        public bool Delete(Goal g);

    }
}
