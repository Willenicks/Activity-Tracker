﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project_Step_9.Models
{
    public class EfActivityRepository : IActivityRepository
    {
        //  F I E L D S  AND P R O P E R T I E S

        private AppDbContext _context;

        // C O N S T R U C T O R S 

        public EfActivityRepository(AppDbContext context)
        {
            _context = context;
        }


        // M E T H O D S 

        // C R E A T E 

        public Activity Create(Activity a)
        {
            _context.Activities.Add(a);
            _context.SaveChanges();
            return a;
        }


        // R E A D 

        public IQueryable<Activity> GetAllActivities()
        {
            return _context.Activities;
        }


        public Activity GetActivityById(int id)
        {
            return _context.Activities.Where(a => a.Id == id).FirstOrDefault();
        }




        // U P D A T E
        public Activity Update(Activity a)
        {
            Activity activityRecordToUpdate = GetActivityById(a.Id);
            if (activityRecordToUpdate != null)
            {
                activityRecordToUpdate.Date = a.Date;
                activityRecordToUpdate.Distance = a.Distance;
                activityRecordToUpdate.Location = a.Location;
                activityRecordToUpdate.Time = a.Time;
                _context.SaveChanges();
            }

            return activityRecordToUpdate;
        }

        // D E L E T E

        public bool Delete(int id)
        {
            Activity ActivityToDelete = GetActivityById(id);
            if(ActivityToDelete == null)
            {
                return false;
            }
            _context.Activities.Remove(ActivityToDelete);
            _context.SaveChanges();
            return true;
        }

    }
}
